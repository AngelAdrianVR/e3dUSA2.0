<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\Pivot;

class ProductSupplier extends Pivot
{
    // No es necesario añadir nada más por ahora,
    // pero aquí podrías definir casts o mutadores si lo necesitaras en el futuro.
}