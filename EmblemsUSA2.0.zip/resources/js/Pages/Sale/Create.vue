<template>
    <AppLayout :title="form.type === 'venta' ? 'Crear Órden de Venta' : 'Crear Órden de Stock'">
        <!-- Panel Flotante de Notas -->
        <BranchNotes v-if="form.branch_id" :branch-id="form.branch_id" />

        <!-- Encabezado -->
        <div class="px-4 sm:px-0 flex justify-between items-center">
            <div class="flex items-center space-x-2">
                <Back :href="route('sales.index')" />
                <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                    {{ form.type === 'venta' ? 'Crear nueva órden de venta' : 'Crear nueva órden de stock' }}
                </h2>
            </div>
        </div>

        <!-- Formulario principal -->
        <div ref="formContainer" class="py-7">
            <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white dark:bg-slate-900 overflow-hidden shadow-xl sm:rounded-lg p-3 md:p-9 relative">
                    <form @submit.prevent="store">
                        <!-- SECCIÓN 1: INFORMACIÓN GENERAL -->
                        <div class="flex justify-between items-center">
                            <el-divider content-position="left" class="flex-grow">
                                <span>Información General</span>
                            </el-divider>
                            <!-- Botón para ver productos de cliente, solo en 'venta' -->
                            <div v-if="form.type === 'venta' && form.branch_id" class="ml-4">
                                <SecondaryButton type="button" @click="showClientProductsDrawer = true">
                                    <i class="fa-solid fa-box-open mr-2"></i>
                                    Ver productos del cliente
                                </SecondaryButton>
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-3">
                            <div class="col-span-full mb-5">
                                <InputLabel value="Tipo de órden*" />
                                <el-radio-group v-model="form.type" size="small">
                                    <el-radio-button label="venta">Orden de Venta</el-radio-button>
                                    <el-radio-button label="stock">Orden de Stock</el-radio-button>
                                </el-radio-group>
                            </div>
                            
                            <!-- Campos exclusivos para 'venta' -->
                            <template v-if="form.type === 'venta'">
                                <div>
                                    <InputLabel value="Cotización relacionada (Opcional)" />
                                    <el-select v-model="form.quote_id" filterable clearable placeholder="Selecciona una cotización" class="!w-full">
                                        <el-option v-for="quote in quotes" :key="quote.id" :label="`COT-${quote.id} - ${quote.branch?.name}`" :value="quote.id" />
                                    </el-select>
                                </div>

                                <div>
                                    <InputLabel value="Cliente*" />
                                     <div class="flex items-center space-x-2">
                                        <el-select v-model="form.branch_id" :disabled="form.quote_id ? true : false" filterable placeholder="Selecciona un cliente" class="!w-full" @change="handleBranchChange">
                                            <el-option v-for="branch in localBranches" :key="branch.id" :label="branch.name" :value="branch.id" />
                                        </el-select>
                                        <el-button @click="branchModalVisible = true" type="primary" circle plain :disabled="form.quote_id ? true : false">
                                            <i class="fa-solid fa-plus"></i>
                                        </el-button>
                                    </div>
                                    <InputError :message="form.errors.branch_id" />
                                </div>

                                 <div>
                                    <InputLabel value="Contacto*" />
                                    <div class="flex items-center space-x-2">
                                        <el-select v-model="form.contact_id" filterable placeholder="Selecciona un contacto" class="!w-full" no-data-text="Selecciona un cliente primero" :disabled="!form.branch_id">
                                            <el-option v-for="contact in availableContacts" :key="contact.id" :label="`${contact.name} (${contact.charge})`" :value="contact.id" />
                                        </el-select>
                                        <el-button @click="contactModalVisible = true" type="primary" circle plain :disabled="!form.branch_id">
                                            <i class="fa-solid fa-plus"></i>
                                        </el-button>
                                    </div>
                                    <InputError :message="form.errors.contact_id" />
                                </div>
                            </template>
                        </div>

                        <!-- Estado de carga -->
                        <LoadingIsoLogo class="my-5" v-if="loadingClientProducts" />

                        <!-- COMPONENTE HIJO PARA PRODUCTOS -->
                        <SaleProductManager v-else
                            v-model="form.products"
                            :branch-id="form.branch_id"
                            :sale-type="form.type"
                            :available-products="productsForManager"
                            :products-error="form.errors.products"
                        />
                        
                        <!-- SECCIÓN 3: LOGÍSTICA (SOLO PARA VENTA) -->
                        <template v-if="form.type === 'venta'">
                            <el-divider content-position="left" class="!mt-8">
                                <span>Logística de la Orden</span>
                            </el-divider>
                            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-3">
                                <div>
                                    <InputLabel value="Opciones de envío*" />
                                    <el-select :disabled="!form.products.length" v-model="form.shipping_option"
                                        placeholder="Selecciona">
                                        <el-option v-for="item in shippingOptions" :key="item" :label="item"
                                            :value="item" />
                                    </el-select>
                                    <small v-if="!form.products.length" class="text-amber-500 text-xs">Agrega un producto a la lista</small>
                                    <InputError :message="form.errors.shipping_option" />
                                </div>
                                
                                <div>
                                    <InputLabel value="Opción de Flete" />
                                    <el-select @change="handleFreightOption" v-model="form.freight_option" placeholder="Selecciona el flete" class="!w-full">
                                        <el-option label="Por cuenta del cliente" value="Por cuenta del cliente" />
                                        <el-option label="Cargo prorrateado en productos" value="Cargo de flete prorrateado en productos" />
                                        <el-option label="La empresa absorbe el costo" value="La empresa absorbe el costo de flete" />
                                        <el-option label="El cliente manda la guia" value="El cliente manda la guia" />
                                    </el-select>
                                </div>
                                <TextInput v-if="form.freight_option !== 'El cliente manda la guia'" label="Costo de Flete*" :error="form.errors.freight_option" v-model="form.freight_cost" type="number" :formatAsNumber="true">
                                    <template #icon-left><i class="fa-solid fa-dollar-sign"></i></template>
                                </TextInput>

                                <!-- ENVÍOS / PARCIALIDADES -->
                                <div v-if="form.products.length" class="col-span-full">
                                    <div v-if="!form.shipping_option" class="text-sm text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-slate-800 p-3 rounded-lg">
                                        <p>Por favor, selecciona una opción de envío para configurar las parcialidades.</p>
                                    </div>
                                    <div v-else class="space-y-6">
                                        <div v-for="(shipment, s_index) in form.shipments" :key="s_index" class="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg border dark:border-slate-700">
                                            <h3 class="font-bold text-lg mb-3 text-gray-800 dark:text-gray-200">Parcialidad {{ s_index + 1 }}</h3>
                                            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-3">
                                                <div>
                                                    <InputLabel value="Fecha promesa de embarque" />
                                                    <el-date-picker
                                                        v-model="shipment.promise_date"
                                                        type="date"
                                                        placeholder="Selecciona una fecha"
                                                        format="YYYY-MM-DD"
                                                        value-format="YYYY-MM-DD"
                                                        :disabled-date="disabledBeforeToday"
                                                    />
                                                    <div v-if="form.errors[`shipments.${s_index}.promise_date`]" class="text-red-500 text-sm mt-1">
                                                    {{ form.errors[`shipments.${s_index}.promise_date`] }}
                                                    </div>
                                                </div>
                                                <div>
                                                    <InputLabel value="Paquetería" />
                                                    <el-select v-model="shipment.shipping_company" filterable clearable placeholder="Selecciona" class="!w-full">
                                                        <el-option v-for="company in shippingCompanies" :key="company" :label="company" :value="company" />
                                                    </el-select>
                                                    <InputError :message="form.errors[`shipments.${s_index}.shipping_company`]" />
                                                </div>
                                                <TextInput label="Guía de rastreo" :error="form.errors[`shipments.${s_index}.tracking_guide`]" v-model="shipment.tracking_guide" />
                                                <div class="col-span-full my-2">
                                                    <InputLabel :value="`Acuse de envío para parcialidad ${s_index + 1}`" />
                                                    <FileUploader @files-selected="shipment.acknowledgement_file = $event[0]" :multiple="false" acceptedFormat="Todo" />
                                                    <InputError :message="form.errors[`shipments.${s_index}.acknowledgement_file`]" />
                                                </div>
                                            </div>
                                            <!-- Productos de la parcialidad -->
                                            <div class="mt-4">
                                                <h4 class="font-semibold text-md mb-2 text-gray-700 dark:text-gray-300">Productos en esta parcialidad</h4>
                                                <div class="overflow-x-auto">
                                                    <table class="w-full text-sm">
                                                        <thead>
                                                            <tr class="text-left text-gray-600 dark:text-gray-400">
                                                                <th class="font-semibold p-2">Producto</th>
                                                                <th class="font-semibold p-2">Total en Venta</th>
                                                                <th class="font-semibold p-2">Cantidad en este envío</th>
                                                                <th class="font-semibold p-2">Restantes por asignar</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr v-for="(product, p_index) in shipment.products" :key="p_index" class="border-t dark:border-slate-700">
                                                                <td class="p-2">
                                                                    <p class="font-medium text-gray-800 dark:text-gray-200">{{ product.name }}</p>
                                                                </td>
                                                                <td class="p-2 text-center dark:text-white">{{ getProductTotalQuantity(product.product_id) }}</td>
                                                                <td class="p-2">
                                                                    <el-input-number 
                                                                        v-model="product.quantity" 
                                                                        :min="0" 
                                                                        :max="getMaxShippableQuantity(product.product_id, s_index)" 
                                                                        :disabled="form.shipments.length === 1"
                                                                        size="small" 
                                                                        controls-position="right" 
                                                                        class="!w-28" />
                                                                </td>
                                                                <td class="p-2 text-center" :class="getRemainingQuantity(product.product_id) < 0 ? 'text-red-500 font-bold' : 'text-green-600'">
                                                                    {{ getRemainingQuantity(product.product_id) }}
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </template>

                        <!-- SECCIÓN 4: DETALLES GENERALES DE LA ORDEN -->
                        <el-divider content-position="left" class="!mt-8 col-span-full">
                            <span>Detalles generales</span>
                        </el-divider>

                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-3">
                            <TextInput v-if="form.type === 'venta'" label="OCE (Orden Compra Externa)" :error="form.errors.oce_name" v-model="form.oce_name" />
                            
                            <div>
                                <InputLabel value="Moneda general*" />
                                <el-select v-model="form.currency" placeholder="Selecciona la moneda" class="!w-full">
                                    <el-option label="MXN (Peso Mexicano)" value="MXN" />
                                    <el-option label="USD (Dólar Americano)" value="USD" />
                                </el-select>
                                <InputError :message="form.errors.currency" />
                            </div>

                            <div v-if="form.type === 'venta'">
                                <InputLabel value="Medio de petición" />
                                <el-select v-model="form.order_via" placeholder="Selecciona el medio">
                                    <el-option v-for="item in orderVias" :key="item" :label="item" :value="item" />
                                </el-select>
                                <InputError :message="form.errors.order_via" />
                            </div>

                            <!-- Archivos de OCE -->
                            <div v-if="form.type === 'venta'" class="col-span-full my-2">
                                <InputLabel value="Archivos de OCE (máx. 3 archivos)" />
                                <FileUploader @files-selected="form.oce_media = $event" :multiple="true" acceptedFormat="Todo" :max-files="3" />
                            </div>
                            <div></div> <!-- Espaciador -->

                            <div class="col-span-full">
                                <TextInput label="Notas generales" v-model="form.notes" :error="form.errors.notes" :isTextarea="true" />
                            </div>
                            
                            <label v-if="form.type === 'venta'" class="flex items-center">
                                <Checkbox v-model:checked="form.is_high_priority" class="bg-transparent border-gray-500" />
                                <span class="ml-2 text-sm text-gray-500 dark:text-gray-300">Prioridad Alta</span>
                            </label>
                        </div>

                        <!-- Botón de envío -->
                        <div class="flex justify-end mt-8 col-span-full">
                            <SecondaryButton :loading="form.processing" :disabled="!form.products.length">
                                Crear Órden
                            </SecondaryButton>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- COMPONENTE HIJO PARA DRAWER (SOLO PARA VENTA) -->
        <ClientProductsDrawer v-if="form.type === 'venta'"
            :show="showClientProductsDrawer"
            @update:show="showClientProductsDrawer = $event"
            :branch-id="form.branch_id"
            @products-loaded="clientProducts = $event"
            :branches="branches"
            :catalog_products="catalog_products"
        />

        <!-- MODALES DE CREACIÓN RÁPIDA -->
        <el-dialog v-model="branchModalVisible" title="Crear Cliente/Prospecto Rápido" width="30%">
            <form @submit.prevent="storeQuickBranch">
                <div class="space-y-4">
                    <TextInput label="Nombre*" v-model="quickBranchForm.name" type="text" :error="quickBranchForm.errors.name" />
                    <TextInput label="RFC" v-model="quickBranchForm.rfc" type="text" :error="quickBranchForm.errors.rfc" />
                </div>
            </form>
            <template #footer>
                <span class="dialog-footer">
                    <el-button @click="branchModalVisible = false">Cancelar</el-button>
                    <el-button type="primary" @click="storeQuickBranch" :loading="quickBranchForm.processing">
                        Guardar
                    </el-button>
                </span>
            </template>
        </el-dialog>

        <el-dialog v-model="contactModalVisible" title="Crear Contacto Rápido" width="30%">
            <form @submit.prevent="storeQuickContact">
                <div class="space-y-4">
                    <TextInput label="Nombre*" v-model="quickContactForm.name" type="text" :error="quickContactForm.errors.name" />
                    <TextInput label="Cargo" v-model="quickContactForm.charge" type="text" :error="quickContactForm.errors.charge" />
                </div>
            </form>
            <template #footer>
                <span class="dialog-footer">
                    <el-button @click="contactModalVisible = false">Cancelar</el-button>
                    <el-button type="primary" @click="storeQuickContact" :loading="quickContactForm.processing">
                        Guardar
                    </el-button>
                </span>
            </template>
        </el-dialog>
    </AppLayout>
</template>

<script>
import AppLayout from "@/Layouts/AppLayout.vue";
import LoadingIsoLogo from '@/Components/MyComponents/LoadingIsoLogo.vue';
import BranchNotes from "@/Components/MyComponents/BranchNotes.vue";
import SecondaryButton from "@/Components/SecondaryButton.vue";
import PrimaryButton from "@/Components/PrimaryButton.vue";
import InputError from "@/Components/InputError.vue";
import InputLabel from "@/Components/InputLabel.vue";
import TextInput from "@/Components/TextInput.vue";
import Checkbox from "@/Components/Checkbox.vue";
import Back from "@/Components/MyComponents/Back.vue";
import FileUploader from "@/Components/MyComponents/FileUploader.vue";
import SaleProductManager from "@/Pages/Sale/Components/SaleProductManager.vue";
import ClientProductsDrawer from "@/Pages/Sale/Components/ClientProductsDrawer.vue";
import { ElMessage, ElMessageBox } from 'element-plus';
import { useForm } from "@inertiajs/vue3";
import { h } from 'vue';
import axios from 'axios';

export default {
    components: {
        Back,
        Checkbox,
        TextInput,
        AppLayout,
        InputError,
        InputLabel,
        BranchNotes,
        FileUploader,
        PrimaryButton,
        LoadingIsoLogo,
        SecondaryButton,
        SaleProductManager,
        ClientProductsDrawer,
    },
    props: {
        branches: Array,
        quotes: Array,
        catalog_products: Array,
        quoteToConvertId: Number,
    },
    data() {
        return {
            form: useForm({
                branch_id: null,
                quote_id: null,
                contact_id: null,
                type: 'venta',
                oce_name: '',
                order_via: '',
                freight_option: 'Por cuenta del cliente',
                freight_cost: 0,
                notes: '',
                currency: 'MXN',
                is_high_priority: false,
                products: [],
                oce_media: null,
                anotherFiles: null,
                shipping_option: null,
                shipments: [], 
            }),
            // --- PROPIEDADES PARA CREACIÓN RÁPIDA ---
            localBranches: [],
            branchModalVisible: false,
            contactModalVisible: false,
            quickBranchForm: {
                name: '',
                rfc: '',
                processing: false,
                errors: {},
            },
            quickContactForm: {
                name: '',
                charge: '',
                processing: false,
                errors: {},
            },
            availableContacts: [],
            clientProducts: [],
            showClientProductsDrawer: false,
            loadingClientProducts: false,
            orderVias: [
                'Correo electrónico',
                'WhatsApp',
                'Llamada telefónica',
                'Resurtido programado',
                'Otro',
            ],
            shippingOptions: [
                'Entrega única',
                '2 parcialidades',
                '3 parcialidades',
                '4 parcialidades',
            ],
            shippingCompanies: [
                'DHL',
                'UPS',
                'FedEx',
                'Estafeta',
                'Paquetexpress',
                'Envío propio',
                'Otro',
            ],
        };
    },
    computed: {
        productsForManager() {
            // Devuelve los productos de cliente para 'venta' o todo el catálogo para 'stock'
            return this.form.type === 'venta' ? this.clientProducts : this.catalog_products;
        }
    },
    watch: {
        branches(newVal) {
            this.localBranches = [...newVal];
        },
        'form.type'(newType) {
            // Limpia el formulario al cambiar de tipo para evitar enviar datos incorrectos
            if (newType === 'stock') {
                this.form.reset(
                    'branch_id', 'quote_id', 'contact_id', 'order_via', 
                    'freight_option', 'freight_cost', 'shipping_option', 'products', 'shipments'
                );
                this.availableContacts = [];
                this.clientProducts = [];
            } else {
                 this.form.reset('products');
            }
        },
        'form.quote_id'(newQuoteId) {
            if (newQuoteId) {
                this.fetchQuoteDetails(newQuoteId);
            } else if (this.form.type === 'venta') {
                this.form.reset('branch_id', 'contact_id', 'freight_option', 'freight_cost', 'notes', 'products');
                this.availableContacts = [];
                this.clientProducts = [];
            }
        },
        'form.shipping_option'(newValue) {
            this.generateShipmentPartials(newValue);
        },
        'form.products': {
            handler() {
                if (this.form.type === 'venta') {
                    this.generateShipmentPartials(this.form.shipping_option);
                }
            },
            deep: true
        }
    },
    methods: {
        store() {
            // Valida las parcialidades solo si es una venta
            if (this.form.type === 'venta' && this.form.shipping_option && this.form.products.length > 0) {
                for (const product of this.form.products) {
                    const remaining = this.getRemainingQuantity(product.id);
                    if (remaining !== 0) {
                        const productName = this.getProductInfo(product.id)?.name || `ID ${product.id}`;
                        ElMessage.error(`Debe asignar la cantidad total para el producto "${productName}". Faltan ${remaining} por asignar.`);
                        return;
                    }
                }
            }
            
            if (this.form.type === 'venta') {
                this.form.shipments.forEach(shipment => {
                    if (shipment.acknowledgement_file && typeof shipment.acknowledgement_file === 'object' && shipment.acknowledgement_file.file) {
                        shipment.acknowledgement_file = shipment.acknowledgement_file.file;
                    }
                });
            }

            this.form.post(route("sales.store"), {
                onSuccess: () => {
                    ElMessage.success('Órden creada correctamente');
                },
                onError: (errors) => {
                    console.error(errors);
                    this.$refs.formContainer.scrollIntoView({ behavior: 'smooth' });
                    ElMessage.error('Por favor, revisa los errores en el formulario.');
                }
            });
        },
        handleFreightOption() {
            if (this.form.freight_option === 'El cliente manda la guia') {
                this.form.freight_cost = 0;
            }
        },
        generateShipmentPartials(option) {
            if (!option || !this.form.products.length || this.form.type !== 'venta') {
                this.form.shipments = [];
                return;
            }

            const count = parseInt(option.split(' ')[0]) || 1;
            const newShipments = [];

            for (let i = 0; i < count; i++) {
                const existingShipment = this.form.shipments[i] || {};
                
                newShipments.push({
                    promise_date: existingShipment.promise_date || null,
                    shipping_company: existingShipment.shipping_company || null,
                    tracking_guide: existingShipment.tracking_guide || '',
                    acknowledgement_file: existingShipment.acknowledgement_file || null,
                    products: this.form.products.map(p => {
                        const existingProduct = existingShipment.products?.find(sp => sp.product_id === p.id);
                        const productInfo = this.getProductInfo(p.id);
                        
                        let quantity = 0;
                        if (count === 1) {
                            quantity = p.quantity;
                        } else {
                            quantity = existingProduct?.quantity || 0;
                        }

                        return {
                            product_id: p.id,
                            quantity: quantity,
                            name: productInfo?.name,
                            part_number: productInfo?.part_number,
                        };
                    })
                });
            }
            this.form.shipments = newShipments;
        },
        getProductInfo(productId) {
            const source = this.form.type === 'venta' ? this.clientProducts : this.catalog_products;
            return source.find(p => p.id === productId);
        },
        getProductTotalQuantity(productId) {
            const productInSale = this.form.products.find(p => p.id === productId);
            return productInSale ? productInSale.quantity : 0;
        },
        getRemainingQuantity(productId) {
            const totalQuantity = this.getProductTotalQuantity(productId);
            const assignedQuantity = this.form.shipments.reduce((sum, shipment) => {
                const productInShipment = shipment.products.find(p => p.product_id === productId);
                return sum + (productInShipment ? productInShipment.quantity : 0);
            }, 0);
            return totalQuantity - assignedQuantity;
        },
        getMaxShippableQuantity(productId, currentShipmentIndex) {
            const totalQuantity = this.getProductTotalQuantity(productId);
            let assignedInOtherShipments = 0;

            this.form.shipments.forEach((shipment, s_index) => {
                if (s_index !== currentShipmentIndex) {
                    const productInShipment = shipment.products.find(p => p.product_id === productId);
                    if (productInShipment) {
                        assignedInOtherShipments += productInShipment.quantity;
                    }
                }
            });

            return totalQuantity - assignedInOtherShipments;
        },
        disabledBeforeToday(date) {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            return date < today;
        },
        async handleBranchChange(branchId) {
            this.form.contact_id = null;
            
            const selectedBranch = this.localBranches.find(b => b.id === branchId);
            this.availableContacts = selectedBranch ? selectedBranch.contacts : [];

            await this.fetchClientProducts();
        },
        async fetchClientProducts() {
            if (!this.form.branch_id) return;
            this.clientProducts = [];
            this.loadingClientProducts = true;
            try {
                const response = await axios.get(route('branches.fetch-products', this.form.branch_id));
                this.clientProducts = response.data;
            } catch (error) {
                console.error("Error fetching client products:", error);
                ElMessage.error('No se pudieron cargar los productos del cliente.');
            } finally {
                this.loadingClientProducts = false;
            }
        },
        async fetchQuoteDetails(quoteId) {
            try {
                const response = await axios.get(route('quotes.details-for-sale', quoteId));
                const quoteData = response.data;

                this.form.branch_id = quoteData.branch_id;
                this.form.freight_option = quoteData.freight_option;
                this.form.freight_cost = quoteData.freight_cost;
                this.form.currency = quoteData.currency;
                this.form.notes = quoteData.notes;

                await this.handleBranchChange(quoteData.branch_id);
                this.form.contact_id = quoteData.contact_id;
                this.processQuoteProducts(quoteData.products);

            } catch (error) {
                console.error("Error fetching quote details:", error);
                ElMessage.error('No se pudo cargar la información de la cotización.');
            }
        },
        async processQuoteProducts(quoteProducts) {
            this.form.products = [];
            const clientProductIds = new Set(this.clientProducts.map(p => p.id));

            for (const product of quoteProducts) {
                if (clientProductIds.has(product.id)) {
                    this.addProductToSaleForm(product);
                } else {
                    try {
                        await ElMessageBox.confirm(
                           '',
                           {
                                title: 'Producto no asignado',
                                message: h('div', { class: 'flex flex-col items-center text-center' }, [
                                    h('img', {
                                        src: product.image_url || 'https://placehold.co/200x200/e2e8f0/e2e8f0?text=N/A',
                                        class: 'w-48 h-48 rounded-lg object-cover border mb-4',
                                        alt: product.name
                                    }),
                                    h('p', null, `El producto "${product.name}" (codigo: ${product.code}) no está asignado a este cliente. ¿Deseas asignarlo y agregarlo a la orden de venta?`)
                                ]),
                                confirmButtonText: 'Sí, asignar y agregar',
                                cancelButtonText: 'No, omitir',
                                type: 'warning',
                           }
                        );
                        await this.associateAndAddProduct(product);
                    } catch (action) {
                        ElMessage.info(`Se omitió el producto: "${product.name}"`);
                    }
                }
            }
        },
        async associateAndAddProduct(product) {
            try {
                const payload = {
                    products: [{ product_id: product.id, price: null }]
                };
                await axios.post(route('branches.add-products', this.form.branch_id), payload);
                ElMessage.success(`Producto "${product.name}" asociado al cliente.`);
                await this.fetchClientProducts();
                this.addProductToSaleForm(product);
            } catch (error) {
                console.error("Error associating product:", error);
                ElMessage.error(`No se pudo asociar el producto "${product.name}".`);
            }
        },
        addProductToSaleForm(product) {
            this.form.products.push({
                id: product.id,
                quantity: product.quantity,
                price: product.unit_price,
                notes: product.notes,
                customization_details: product.customization_details || [],
                is_new_design: false,
            });
        },
        // --- MÉTODOS NUEVOS PARA CREACIÓN RÁPIDA ---
        async storeQuickBranch() {
            this.quickBranchForm.processing = true;
            this.quickBranchForm.errors = {};
            try {
                const response = await axios.post(route('branches.quick-store'), this.quickBranchForm);
                if (response.status === 200) {
                    const newBranch = response.data;
                    this.localBranches.push(newBranch);
                    this.form.branch_id = newBranch.id;
                    await this.handleBranchChange(newBranch.id); // Llama para actualizar contactos y productos
                    this.branchModalVisible = false;
                    this.quickBranchForm.name = '';
                    this.quickBranchForm.rfc = '';
                    ElMessage.success('Cliente/Prospecto creado exitosamente');
                }
            } catch (error) {
                if (error.response && error.response.status === 422) {
                    this.quickBranchForm.errors = error.response.data.errors;
                } else {
                    console.error(error);
                    ElMessage.error('Ocurrió un error al crear el cliente.');
                }
            } finally {
                this.quickBranchForm.processing = false;
            }
        },
        async storeQuickContact() {
            if (!this.form.branch_id) {
                 ElMessage.warning('Primero debes seleccionar un cliente.');
                 return;
            }
            this.quickContactForm.processing = true;
            this.quickContactForm.errors = {};
            try {
                const response = await axios.post(route('branches.quick-store.contact', { branch: this.form.branch_id }), this.quickContactForm);
                if (response.status === 200) {
                    const newContact = response.data;
                    this.availableContacts.push(newContact);
                    
                    const parentBranch = this.localBranches.find(b => b.id === this.form.branch_id);
                    if (parentBranch) {
                        parentBranch.contacts.push(newContact);
                    }

                    this.form.contact_id = newContact.id;
                    this.contactModalVisible = false;
                    this.quickContactForm.name = '';
                    this.quickContactForm.charge = '';
                    ElMessage.success('Contacto creado exitosamente');
                }
            } catch (error)
            {
                if (error.response && error.response.status === 422) {
                    this.quickContactForm.errors = error.response.data.errors;
                } else {
                    console.error(error);
                    ElMessage.error('Ocurrió un error al crear el contacto.');
                }
            } finally {
                this.quickContactForm.processing = false;
            }
        },
    },
    created() {
        this.localBranches = [...this.branches];
    },
    mounted() {
        if (this.quoteToConvertId) {
            this.form.quote_id = Number(this.quoteToConvertId);
        }
    }
};
</script>
