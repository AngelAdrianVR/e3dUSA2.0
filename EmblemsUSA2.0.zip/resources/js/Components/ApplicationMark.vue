<template>
    <figure class="size-14 mb-3 mx-auto relative p-2">
        <img class="w-full h-full object-contain rounded-full" src="/images/isoLogoEmblems.png"
            alt="Logo de la Empresa" />
    </figure>
</template>
