<script setup>
import { Link } from '@inertiajs/vue3';
</script>

<template>
    <Link :href="'/'">
    <figure>
        <img class="mx-auto" src="@/../../public/images/logo.png" alt="Logo">
    </figure>
    </Link>
</template>
