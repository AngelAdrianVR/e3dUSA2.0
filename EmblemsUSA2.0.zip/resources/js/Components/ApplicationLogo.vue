<template>
    <figure>
        <img class="h-12" src="@/../../public/images/logo.png" alt="Logo">
    </figure>
</template>
